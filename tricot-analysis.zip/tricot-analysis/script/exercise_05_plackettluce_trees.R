# ................................
# ................................
# Here is the exercise from the 
# Plackett-Luce trees

# ................................
# ................................
# ................................
# 1. Fetch the your tricot data using your API key 
#    or from someone in your research group



# ................................
# ................................
# 2. Fit a PlackettLuce model without covariates




# ................................
# ................................
# 3. Export the summary of this model as a text file 
#  to the output folder in your project directory



# ................................
# ................................
# 4. Select two or more covariates to fit a pltree



# ................................
# ................................
# 5. Fit the pltree





# ................................
# ................................
# 6. Plot the tree and export the summaries of this model as a text file












