# ................................
# ................................
# Here is the exercise from the 
# tricot rankings into PlackettLuce rankings

# ................................
# ................................
# ................................
# 1. Load the packages gosset, ClimMobTools and PlackettLuce


# 2. Fecth the project data from the previous exercise



# 3. Select the columns that are used for this process and 
#  and assign a new object 



# 4. Use the function rank_tricot() to create the rankings
# Attention to the order of the elements in the input and items vector
# they should be in the order of itemA, itemB, itemC and best, worst



# 5. Get it as a sparse matrix


# 6. Load the beans data from PlackettLuce


# 7. Use the function rank_tricot to create the PlackettLuce rankings
# you must include the local variety with additional.rankings 



# Hint 1. Check the function documentation to see examples
# ?rank_tricot



