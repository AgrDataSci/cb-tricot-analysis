# ................................
# ................................
# Here is the exercise from the 
# ClimMob data in R

# ................................
# ................................
# ................................
# 1. Load the package ClimMobTools



# 2. Check the projects in the user account 
#  that you are working with



# 3. Fetch the project data of your preference 
# in the wider format


# Hint 1: check the script 03_climmob_data_in_r.R to see the example
# Hint 2: use the command ?getDataCM() to see the function documentation


