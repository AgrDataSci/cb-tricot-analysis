# ................................
# ................................
# Here is the exercise from the 
# Visualization and Summary section

# read the sweetpotato data
# filter the data to keep only the Ghana data  
# make a table showing the number of varieties that were tested in each district


# make another table with the number of varieties by gender 



# make a PlackettLuce rankings with the data 


# check the favourability scores 


# the victories






