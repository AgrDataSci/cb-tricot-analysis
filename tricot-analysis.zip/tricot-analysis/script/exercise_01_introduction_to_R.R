# Here is the exercise from the 
# Introduction to R

# ................................
# ................................
# ................................


# 1. Install the packages tidyverse, climatrends and remotes
# using the function install.packages()
# block the line using # after you have installed the packages



# 2. Install the packages PlackettLuce, ClimMobTools and gosset
# using the function install_github() from the package remotes
# PlackettLuce is hosted at hturner/
# ClimMobTools and gosset are hosted at agrdatasci/
# block the line using # after you have installed the packages


# 3. Load the five packages using the function library()


# 4. Create a vector of integers with length 7


# 5. Create a vector of logical with length 7


# 6. Create a vector character with length 7


# 7. Create a data frame with these three vectors
# using the function data.frame()


# 8. Select the rows from 1 to 3 and all the columns 
# in the previous data.frame


# 9. Select the rows 3 and 7 and only the column with 
# character and logical from the previous data.frame
# select the columns using the names 






















